#include <stdio.h>
int main() {
printf("hellow\n");
}

